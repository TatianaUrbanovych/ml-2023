OK_FORMAT = True
test = {'name': 'q6', 'points': 1, 'suites': [{'cases': [{'code': '>>> kol_uniq_symb == 26\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
